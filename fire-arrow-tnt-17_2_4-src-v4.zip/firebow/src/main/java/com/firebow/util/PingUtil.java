package com.firebow.util;

import net.minecraft.client.MinecraftClient;

/** Đọc ping thực từ server tab list. */
public final class PingUtil {
    private PingUtil() {}

    public static long getPingMs(MinecraftClient client) {
        if (client.player == null || client.getNetworkHandler() == null) return 50L;
        try {
            var entry = client.getNetworkHandler()
                .getPlayerListEntry(client.player.getUuid());
            if (entry != null && entry.getLatency() > 0)
                return entry.getLatency();
        } catch (Exception ignored) {}
        return 50L;
    }

    /** Delay bổ sung dựa vào ping. 0 nếu ping tốt, cộng thêm nếu lag. */
    public static long lagBonus(MinecraftClient client) {
        long ping = getPingMs(client);
        return ping > 150 ? (ping - 150) / 4 : 0L;
    }
}
